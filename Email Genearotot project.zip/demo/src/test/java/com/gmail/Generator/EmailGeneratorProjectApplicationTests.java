package com.gmail.Generator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailGeneratorProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
